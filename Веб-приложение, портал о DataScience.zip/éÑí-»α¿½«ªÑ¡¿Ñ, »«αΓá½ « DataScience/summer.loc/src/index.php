<!DOCTYPE html>
<html lang="ru">
<head>
<?php
    require_once "functions/functions.php";
  ?>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" href="img/icon/data.ico">
  <?php
    $news = getNews(100, "");
  ?>

  <title>Data Science</title>
</head>
<body>

  <?php include 'includes/header.php'; ?>


    
    <section class="main">
        <div class="container">
          <div class="main-block">

          <?php 
            for ($i = 0; $i < count($news); $i++){
              $show_img = base64_encode($news[$i]["img"]);
              echo  "<div class=\"article\">
            <div class=\"article-top\">
              <span class=\"article-top__text\">".$news[$i]["date"].", ".$news[$i]["kind"]."</span>
            </div>
            <div class=\"article-title\">
              <h2 class=\"article-title__text\">".$news[$i]["title"]."</h2>
            </div>
            <div class=\"article-img\">
              <img src=\"data:image/jpeg;base64, ".$show_img."\" alt=\"article-img\">
            </div>
            <div class=\"article-intro\">
              <span class=\"link-intro info__text\"><p class='info__text'>";echo nl2br($news[$i]["intro_text"]); echo"
              <a href=\"article.php?id=".$news[$i]["id"]."\" class=\"link-intro link-intro__a\"> . . .</a></p></span>
            </div>
            <button class=\"article-btn button\" onclick=\"location.href='article.php?id=".$news[$i]["id"]."'\">Далее</button>
          </div>";
     }
  ?>
            <?php include 'includes/search-form.php'; ?>

            <div class="suggest">
              <div class="suggest-text">
                <h2 class="suggest-text__title">Предложения</h2>
                <a href="#" class="suggest-text__order" id="suggest__order">Предложить идею</a>
              </div>
            </div>

          </div>
          <!-- /.hero-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.hero -->


  <?php include 'includes/footer.php'; ?>


</body>
</html>