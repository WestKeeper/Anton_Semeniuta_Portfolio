$(document).ready(function(){
  /* Валидация формы */
   $('#hero__form').validate({
    rules:{
      username: {
        required: true,
        minlength: 2,
        maxlength: 15
      },
      email:{
        required: true,
        email: true
      },
      text:{
        required: true,
        minlength: 5,
        maxlength: 200,
      }
    },
    messages:{
      username: {
        required: "Укажите имя",
        minlength: jQuery.validator.format("Впишите минимум {0} символа!"),
        maxlength: jQuery.validator.format("Имя может содержать максимум {0} символов!")
      },
      email: {
        required: "Нам нужен Ваш e-mail",
        email: "Введите корректный e-mail"
      },
      text:{
        required: "Укажите имя",
        minlength: jQuery.validator.format("Впишите минимум {0} символов!"),
        maxlength: jQuery.validator.format("Сообщение может содержать максимум {0} символов!")
      }
    },
    			//Обработчик и отправка данных
			submitHandler: function(form){
				$('#hero__form').ajaxSubmit({
          url: 'mail.php',
          type: 'POST',
          data: $(this).serialize(),
          success: function(data){
            $('.hero__input_1').val('');
            $('.hero__input_2').val('');
            $('.hero__input_3').val('');
            $('.modal-thx').addClass('modal-thx_active');
            console.log(data);
          },
          error: function(jqXHR, textStatus){
            console.log(jqXHR + ': ' + textStatus);
          }
				}); 
			}
  });

});

$(document).ready(function(){
  $('#hero__form-new').validate({
    rules:{
      username: {
        required: true,
        minlength: 2,
        maxlength: 15
      },
      email:{
        required: true,
        email: true
      },
      text:{
        required: true,
        minlength: 5,
        maxlength: 200,
      }
    },
    messages:{
      username: {
        required: "Укажите имя",
        minlength: jQuery.validator.format("Впишите минимум {0} символа!"),
        maxlength: jQuery.validator.format("Имя может содержать максимум {0} символов!")
      },
      email: {
        required: "Нам нужен Ваш e-mail",
        email: "Введите корректный e-mail"
      },
      text:{
        required: "Укажите имя",
        minlength: jQuery.validator.format("Впишите минимум {0} символа!"),
        maxlength: jQuery.validator.format("Сообщение может содержать максимум {0} символов!")
      }
    },
    //Обработчик и отправка данных
      submitHandler: function(form){
        $('#hero__form-new').ajaxSubmit({
          url: 'mail.php',
          type: 'POST',
          data: $(this).serialize(),
          success: function(data){
            $('.hero__input_1').val('');
            $('.hero__input_2').val('');
            $('.hero__input_3').val('');
            $('#modal-new').removeClass('modal-new_active');
            $('.modal-thx').addClass('modal-thx_active');
            console.log(data);
          },
          error: function(jqXHR, textStatus){
            console.log(jqXHR + ': ' + textStatus);
          }
        }); 
      }
  });
});



$(document).ready(function(){
  $('#form__comments').validate({
    rules:{
      author: {
        required: true,
        minlength: 2,
        maxlength: 15
      },
      message:{
        required: true,
        minlength: 5,
        maxlength: 400,
      }
    },
    messages:{
      author: {
        required: "Укажите имя",
        minlength: jQuery.validator.format("Впишите минимум {0} символа!"),
        maxlength: jQuery.validator.format("Имя может содержать максимум {0} символов!")
      },
      message:{
        required: "Укажите имя",
        minlength: jQuery.validator.format("Впишите минимум {0} символов!"),
        maxlength: jQuery.validator.format("Сообщение может содержать максимум {0} символов!")
      }
    }
  });
});