$(document).ready(function(){
  var modal = $('#modal-thx');
  var close = $('#close-thx');
  var footerOrder = $('#footer__order');
  var modalNew = $('#modal-new');
  var closeNew = $('#close-thx-new');
  var suggestOrder = $('#suggest__order');
  var course = $('#course-suggest');

  footerOrder.on('click',function(){
    modalNew.addClass('modal-new_active');
  });

  suggestOrder.on('click',function(){
    modalNew.addClass('modal-new_active');
  });

  closeNew.on('click',function(){
    modalNew.removeClass('modal-new_active');
  });

   close.on('click',function(){
    modal.removeClass('modal-thx_active');
  }); 

  course.on('click',function(e){
    e.preventDefault;
    modalNew.addClass('modal-new_active');
  });
  
});
