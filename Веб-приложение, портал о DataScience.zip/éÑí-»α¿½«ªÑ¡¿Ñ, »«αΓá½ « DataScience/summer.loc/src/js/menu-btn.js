$(document).ready(function(){
  var menuBtn = $('#menu-btn');
  var menuModal = $('#modal-menu');

  var base = $('#base-knowledge');
  var lang = $('#lang');
  var dc = $('#dc');
  var convertion = $('#convertion');
  var high = $('#high-level');
  var baseSub = $('#base-knowledge-sub');
  var langSub = $('#lang-sub');
  var dcSub = $('#dc-sub');
  var convertionSub = $('#convertion-sub');
  var highSub = $('#high-level-sub');

  menuBtn.on('click',function(e){
    e.preventDefault;
    menuBtn.toggleClass('navbar__menu-btn_active');
    menuModal.toggleClass('modal-menu_active');
  });

  base.on('click',function(e){
    e.preventDefault;
    baseSub.toggleClass('navbar__modal-sub_active');
  });
  
  lang.on('click',function(e){
    e.preventDefault;
    langSub.toggleClass('navbar__modal-sub_active');
  });
  
  dc.on('click',function(e){
    e.preventDefault;
    dcSub.toggleClass('navbar__modal-sub_active');
  });
  
  convertion.on('click',function(e){
    e.preventDefault;
    convertionSub.toggleClass('navbar__modal-sub_active');
  });
  
  high.on('click',function(e){
    e.preventDefault;
    highSub.toggleClass('navbar__modal-sub_active');
  });

  
});