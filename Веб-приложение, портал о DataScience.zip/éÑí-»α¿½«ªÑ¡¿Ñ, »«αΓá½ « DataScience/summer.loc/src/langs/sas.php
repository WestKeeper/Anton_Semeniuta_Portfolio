<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" href="img/icon/data.ico">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">

  <title>SAS</title>
</head>
<body>

  <?php include 'includes/header.php'; ?>


    
    <section class="main">
        <div class="container">
          <div class="main-block">
            <div class="info">
              
            <img src="img/sas/SAS_1.png" alt="SAS-intro" class="info__img info__img-lang">
              <div class="info-title">
                <h2 class="info-title__title">О языке SAS</h2>
              </div>
              <p class="info__text">Язык SAS – это язык программирования, используемый для статистического анализа, 
                разработанный Джеймсом Барром в университете, расположенном в штате Северная Каролина, США. 
                Он может считывать информацию с простых таблиц и баз данных и выводить результат анализа в виде таблиц, 
                графиков, а также в виде файлов формата RTF, HTML и PDF. Язык SAS запускается компилятором, 
                который может использоваться в таких ОС как Microsoft Windows, Linux, и других UNIX-подобных системах.</p>
              <div class="info-theme">
                <h3 class="info-theme__theme">Историческая справка</h3>
              </div>
              <p class="info__text">Изначально SAS был довольно примитивным набором шаблонных запросов для группировки данных, 
                но со временем он стал полноценным и достаточно популярным языком программирования.</p>
              <p class="info__text">С этого момента можно было бы смело вести историю языка, программного обеспечения и всей компании, 
                как единого целого, но в 2002 году объявился идеологический конкурент - World Programming System (WPS), 
                который в своей деятельности не просто стал использовать язык SAS, но и разработал для него собственный компилятор и IDE.</p> 
              <p class="info__text">Разумеется, вскоре началась судебная тяжба, 
                которая в итоге создала интересный прецедент для всего IT-сообщества: 
                WPS выиграл суд, доказав, что авторское право не нарушается, если используется синтаксис и функциональность языка, 
                но не используются исходные коды. Таким образом, язык SAS отчасти избежал участи MATLAB, сорвав ярлык “вещи в себе”.</p>
              <div class="info-theme">
                <h3 class="info-theme__theme">Синтаксис</h3>
              </div>
              <p class="info__text">PROC PRINT DATA = models NOOBS;
                WHERE Type = "Mountain";
                FORMAT Price DOLLAR6.;
                TITLE "Current Models of Mountain Bicycles";
                RUN;
              </p>
              <div class="info-theme">
                <h3 class="info-theme__theme">Достоинства и недостатки</h3>
              </div>
              <p class="info__text">Основным конкурентом SAS является язык R, причём стоит признать, что последний имеет солидное преимущество. 
                Во-первых, он был создан позднее, соответственно избежал многих проблем роста. 
                Во-вторых, и это, наверное, главный фактор, он бесплатный, 
                в то время как SAS требует дорогое программное обеспечение. 
                Впрочем, давайте взглянем на преимущества и недостатки SAS в сравнении с главным конкурентом.</p>
              <ul class="article-ul__top">
                <li class="info__text">Плюсы:
                  <ul class="article-ul__top">
                    <li class="article-li__top">Простой синтаксис, быстрое обучение “с нуля”</li>
                    <li class="article-li__top">Отладка кода проходит значительно проще, чем на R</li>
                    <li class="article-li__top">Интеграция с БД (Oracle/Teradata)</li>
                    <li class="article-li__top">Удобный формат выходных данных (особенно таблиц)</li>
                    <li class="article-li__top">Мощная поддержка со стороны компании SAS</li>
                    <li class="article-li__top">Многолетний успешный опыт эксплуатации компаниями разной величины, 
                      с разными задачами и разным объёмом входных данных. 
                      В частности, России SAS используют ОАО “РЖД”, МТС, ЦБ РФ, а также ведущие банки, 
                      среди которых Сбербанк, Альфабанк, Тинькофф и многие другие</li>
                  </ul>
                </li>
                <li class="info__text">Минусы:
                  <ul class="article-ul__top">
                    <li class="article-li__top">Профессиональное использование языка предполагает покупку программного продукта</li>
                    <li class="article-li__top">Исходники многих исполняемых алгоритмов SAS не являются публичными, 
                      следовательно, изучение работы языка сильно ограничено;</li>
                    <li class="article-li__top">SAS значительно уступает в производительности R;</li>
                    <li class="article-li__top">С точки зрения объёма кода SAS также зачастую сильно проигрывает (иногда в несколько раз)</li>
                  </ul>
                </li>
              </ul>
              <div class="info-theme">
                <h3 class="info-theme__theme">Роль языка в анализе и обработке данных</h3>
              </div>
              <p class="info__text">При всем различии языков SAS и R надо понимать, 
                что далеко не во всех сферах они являются прямыми конкурентами. 
                Взгляните на следующее изображение:</p>
              <img src="img/sas/SAS_2.png" alt="SAS-infographics" class="info__img info__img-scheme">
              <p class="info__text">На этом графике видно, 
                что SAS больше заточен на решение проблемы анализа данных и использует метод predictive analytics, 
                т.е. пытается предсказать дальнейшее поведение модели, 
                в то время как язык R больше направлен на комплексное решение проблем обработки и анализа данных.</p>
              <br/><br/>
              <p class="info__text">Больше информации о языке SAS <a href="https://www.sas.com" class="footer__order">на сайте</a></p> 
            </div>

          </div>
          <!-- /.main-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.main -->


  <?php include 'includes/footer.php'; ?>


</body>
</html>