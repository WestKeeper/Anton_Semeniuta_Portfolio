<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">

  <title>R</title>
</head>
<body>

  <?php include 'includes/header.php'; ?>


    
    <section class="main">
        <div class="container">
          <div class="main-block">
            <div class="info">
              <img src="img/R/R_1.png" alt="SAS-intro" class="info__img info__img-lang info__img-r">
              <div class="info-title">
                <h2 class="info-title__title">О языке R</h2>
              </div>
              <p class="info__text">R — язык программирования для статистической обработки данных и работы с графикой, 
                а также свободная программная среда вычислений с открытым исходным кодом в рамках проекта GNU. 
                Язык создавался как аналогичный языку S, разработанному в Bell Labs, и является его альтернативной реализацией, 
                хотя между языками есть существенные отличия, но в большинстве своём код на языке S работает в среде R. 
                Изначально R был разработан сотрудниками статистического факультета Оклендского университета Россом Айхэкой (англ. Ross Ihaka) 
                и Робертом Джентлменом (англ. Robert Gentleman) (первая буква их имён — R); 
                язык и среда поддерживаются и развиваются организацией R Foundation.</p>
              <p class="info__text">R широко используется как статистическое программное обеспечение для анализа данных 
                и фактически стал стандартом для статистических программ.</p>
              <p class="info__text">R доступен под лицензией GNU GPL. 
                Распространяется в виде исходных кодов, 
                а также откомпилированных приложений под ряд операционных систем: 
                FreeBSD, Solaris и другие дистрибутивы Unix и Linux, Microsoft Windows, Mac OS X.</p>
              <p class="info__text">В R используется интерфейс командной строки, хотя доступны и несколько графических интерфейсов пользователя, 
                например пакет R Commander, RKWard, RStudio, Weka, Rapid Miner, KNIME, а также средства интеграции в офисные пакеты.</p>
              <p class="info__text">В 2010 году R вошёл в список победителей конкурса журнала Infoworld 
                в номинации на лучшее открытое программное обеспечение для разработки приложений.</p>
              <div class="info-theme">
                <h3 class="info-theme__theme">Особенности</h3>
              </div>
              <p class="info__text">R поддерживает широкий спектр статистических и численных методов 
                и обладает хорошей расширяемостью с помощью пакетов. 
                Пакеты представляют собой библиотеки для работы специфических функций или специальных областей применения. 
                В базовую поставку R включен основной набор пакетов, а всего по состоянию на 2017 год доступно более 11778 пакетов.</p>
              <p class="info__text">Ещё одна особенность R — возможность создания качественной графики, 
                которая может включать математические символы.</p> 
              <div class="info-theme">
                <h3 class="info-theme__theme">Базовый синтаксис</h3>
              </div>
              <pre><code>
                > x <- c(1,2,3,4,5,6)   # Создать упорядоченную коллекцию
                > y <- x^2              # Возвести в квадрат элементы из x
                > print(y)              # Вывести y
                [1]  1  4  9 16 25 36
                > mean(y)               # Рассчитать среднее арифметическое y;
                результат - число
                [1] 15.16667
                > var(y)                # Рассчитать дисперсию
                [1] 178.9667
              </code></pre>
              <div class="info-theme">
                <h3 class="info-theme__theme">Инструменты</h3>
              </div>
              <p class="info__text">Для удобства работы с R разработан ряд графических интерфейсов, 
                в том числе RStudio, JGR, RKWard, SciViews-R, Statistical Lab, R Commander, Rattle.</p>
              <p class="info__text">Кроме того, в ряде текстовых и кодовых редакторов предусмотренные специальные режимы для работы с R, 
                в частности в ConTEXT, Emacs(Emacs Speaks Statistics), jEdit, Kate, Notepad++, Syn, TextMate, Tinn-R, 
                Vim, Bluefish, WinEdt (с пакетом RWinEdt), Gedit (с пакетом rgedit/gedit-r-plugin). 
                Для среды разработки Eclipse существует специализированный R-плагин; 
                доступ к функциям и среде выполнения R возможен из Python с использованием пакета RPy; 
                работать с R можно из эконометрического пакета Gretl.</p>
              <div class="info-theme">
                <h3 class="info-theme__theme">CRAN</h3>
              </div>
              <p class="info__text">R и дополнительные пакеты распространяются через CRAN (акроним Comprehensive R Archive Network). 
                В настоящее время в мире доступны более 60 зеркал CRAN. 
                Головной узел — (http://cran.r-project.org/) расположен в Вене (Австрия).</p>
              <p class="info__text">Больше информации о языке R <a href="https://www.r-project.org/" class="footer__order">на сайте</a></p> 
            </div>

          </div>
          <!-- /.main-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.main -->


  <?php include 'includes/footer.php'; ?>


</body>
</html>