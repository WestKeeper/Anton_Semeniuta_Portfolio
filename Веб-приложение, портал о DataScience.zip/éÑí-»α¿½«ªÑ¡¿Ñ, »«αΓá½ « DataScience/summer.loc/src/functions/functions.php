<?php
  $mysqli = false;

  function connectDB(){
    global $mysqli;
    //$mysqli = new mysqli("localhost", "root", "", "test1Base");
    $mysqli = new mysqli("localhost", "westk193_bd", "adminme1", "westk193_bd");
    if ($mysqli->connect_error) {
      die ('Ошибка подключения к БД: ( ' . $mysqli->connect_errno . ') ');
    }
    $mysqli->query("SET NAMES 'utf8'");
  }
  
  function closeDB(){
    global $mysqli;
    $mysqli->close();
  }

  function getNews($limit, $id){
    global $mysqli;
    connectDB();
    if ($id)
      $where = "WHERE id = ".$id;
    $result = $mysqli->query("SELECT * FROM news $where ORDER BY id DESC LIMIT $limit");
    closeDB();
    if (!$id)
      return resultToArray($result);
    else 
      return $result->fetch_assoc();
  }

  function resultToArray($result){
    $array = array();
    while (($row = $result->fetch_assoc()) != false)
      $array[] = $row;
    $result->close();
    return $array;
  }

  function searchDB($query){
    global $mysqli;
    connectDB();
    $result_set = $mysqli->query($query);
    $mysqli->close();
    return $result_set;
  }
  function comments($title, $author, $message){
    global $mysqli;
    connectDB();
    $sql = "CREATE TABLE IF NOT EXISTS comments (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    author VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    comment_date DATE NOT NULL,
    comment_message TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
    ) ENGINE = MyISAM CHARSET=utf8 COLLATE utf8_general_ci";
    
    $mysqli->query($sql);
    $mysqli->query( "INSERT INTO comments VALUES (NULL, '$title', '$author', CURRENT_DATE(), '$message')" );
    $mysqli->close();
    return $result_set;
  }

  function checkComments($title){
    global $mysqli;
    connectDB();
    $result = $mysqli->query("SELECT * FROM comments WHERE title = '$title' ORDER BY id DESC");
    closeDB();
    if($result){
      return resultToArray($result);
    }
    return null;
  }
?>