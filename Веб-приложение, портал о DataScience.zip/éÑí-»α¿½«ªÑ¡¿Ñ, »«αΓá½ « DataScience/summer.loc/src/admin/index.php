<?php
  require_once "../functions/functions.php";
  if(isset($_POST["username"]) and isset($_POST["password"])){
    $username = $_POST["username"];
    $password = $_POST["password"];

    $query = "SELECT * FROM users WHERE user_login = '$username' AND user_password = '$password'";
    $result = searchDB($query);
    $count = mysqli_num_rows($result);

    if ($count == 1){
      $_SESSION['username'] = $username;
    }
    else{
      $fmsg = "Ошибка";
    }
  }

?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="../css/normalize.css">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="icon" href="../img/icon/data.ico">

  <title>Admin</title>
</head>
<body>

<?php
  
if(!isset($_SESSION['username'])) {
    echo "    <section class=\"admin-section\">
    <div class=\"container\">
      <div class=\"main-block\">

    <div class=\"modal-new  modal-new_active\" id=\"admin\">
      <div class=\"hero-form hero-form-new\">
      <form method=\"POST\" class=\"form hero__form hero__form-new\" id=\"admin-form\">
          <div class=\"hero__form-wrap hero__form-wrap-new\">
            <h3 class=\"hero__form-title hero__form-title-new\">Авторизация</h3>
            <input type=\"text\" name=\"username\" class=\"input hero__input hero__input-new hero__input_1\" placeholder=\"Ваш логин\">
            <input type=\"password\" name=\"password\" class=\"input hero__input hero__input-new hero__input_2\" placeholder=\"Ваш пароль\">
          </div>
            <button class=\"button hero__button hero__button-new\" id=\"button-admin-form\" type=\"submit\">Отправить</button>
      </form>
  </div>
</div>

      </div>
      <!-- /.main-block -->
    </div>
    <!-- /.container -->
  </section>
  <!-- /.admin-section -->";
  }
  else{
    
    echo "
    <style>
      .hero-form{
        min-width: 30%;
      }
      .hero__form-news{
        padding-bottom: 5px;
      }
    </style>
    <section class=\"admin-section\">
    <div class=\"container\">
      <div class=\"main-block\">

      <div class=\"modal-new  modal-new_active\" id=\"\">
      <div class=\"hero-form hero-form-new hero-form-new-div\">
      <form action=\"add-news.php\" method=\"POST\" class=\"form hero__form hero__form-new hero__form-news\" id=\"\" enctype=\"multipart/form-data\">
          <div class=\"hero__form-wrap hero__form-wrap-new\">
            <h3 class=\"hero__form-title hero__form-title-new\">Добавление новости</h3>
            <input type=\"text\" name=\"title\" class=\"input hero__input hero__input-new hero__input_1\" placeholder=\"Заголовок\">
            <input type=\"text\" name=\"kind\" class=\"input hero__input hero__input-new hero__input_2\" placeholder=\"Разновидность\">
            <input type=\"text\" name=\"author\" class=\"input hero__input hero__input-new hero__input_2\" placeholder=\"Автор\">
            <input type=\"file\" name=\"picture\" class=\"input hero__input hero__input-new hero__input_2\" value=\"Изображение\">
            <textarea type=\"text\" name=\"intro\" class=\"input hero__input hero__input-new hero__input_3\" placeholder=\"Вступительный абзац\"></textarea>

            <textarea type=\"text\" name=\"full\" class=\"input hero__input hero__input-new hero__input_3\" placeholder=\"Абзац статьи\"></textarea>
            
          </div>
            <button class=\"button hero__button hero__button-new\" id=\"button-news\" type=\"submit\">Добавить новость</button>
      </form>
      
      <button class=\"button hero__button hero__button-new\" onclick=\"location.href='logout.php'\">Выйти</button>
  </div>
</div>


      

      </div>
      <!-- /.main-block -->
    </div>
    <!-- /.container -->
  </section>
  <!-- /.admin-section -->";
    
    
    
  }
?>

    

<script src="js/jquery-3.3.1.js"></script>

</body>
</html>