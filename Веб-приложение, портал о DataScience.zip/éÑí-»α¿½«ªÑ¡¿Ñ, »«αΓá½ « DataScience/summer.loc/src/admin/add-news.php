<?php
  require_once "../functions/functions.php";

  $title = $_POST['title'];
  $kind = $_POST['kind'];
  $author = $_POST['author'];
  $intro = $_POST['intro'];
  $full = $_POST['full'];
  $img = '';
  if (!empty($_FILES['picture']['tmp_name'])){
    $img = addslashes(file_get_contents($_FILES['picture']['tmp_name']));
  }

  searchDB("INSERT INTO news VALUES (NULL, '$author', '$kind', CURRENT_DATE(), '$intro', '$full', '$title','$img')");
  header('Location: index.php');
  exit;
?>