<?php
	// пример использования SendMailSmtpClass.php

	require_once "SendMailSmtpClass.php"; // подключаем класс
	$data_post = $_POST;
	echo json_encode($data_post, JSON_UNESCAPED_UNICODE);
	$mailSMTP = new SendMailSmtpClass('datasciencea@yandex.ru', 'Y5RMr-eUEUA9M5W', 'ssl://smtp.yandex.ru', 465, "UTF-8");
	// $mailSMTP = new SendMailSmtpClass('zhenikipatov@yandex.ru', '***', 'ssl://smtp.yandex.ru', 465, "windows-1251");
	//$mailSMTP = new SendMailSmtpClass('datasciencea@mail.ru', 'GknYi.QS,kh.9n7', 'ssl://smtp.mail.ru', 465, "UTF-8");
	// $mailSMTP = new SendMailSmtpClass('red@mega-dev.ru', '***', 'ssl://smtp.beget.com', 465, "UTF-8");
	// $mailSMTP = new SendMailSmtpClass('red@mega-dev.ru', '***', 'smtp.beget.com', 2525, "windows-1251");
	// $mailSMTP = new SendMailSmtpClass('red@mega-dev.ru', '***', 'ssl://smtp.beget.com', 465, "utf-8");
	//$mailSMTP = new SendMailSmtpClass('red@mega-dev.ru', '***', 'smtp.beget.com', 2525, "utf-8");
	// $mailSMTP = new SendMailSmtpClass('логин', 'пароль', 'хост', 'порт', 'кодировка письма');
	
	$username = $data_post['username'];
    $email = $data_post['email'];
    $text = $data_post['text'];
	// от кого
	$from = array(
		"Admin Data-Science", // Имя отправителя
		"datasciencea@yandex.ru" // почта отправителя
	);
	// кому отправка. Можно указывать несколько получателей через запятую
	$to = 'antonsemenyuta@yandex.ru';
	
	// добавляем файлы
	//$mailSMTP->addFile("test.jpg");
	//$mailSMTP->addFile("test2.jpg");
	//$mailSMTP->addFile("test3.txt");
    
    $words = 'Пользователь '.$username.' оставил cообщение, его почта '.$email.':<br>'.$text;
	// отправляем письмо
	$result =  $mailSMTP->send($to, 'Сообщение с сайта', $words, $from); 
	// $result =  $mailSMTP->send('Кому письмо', 'Тема письма', 'Текст письма', 'Отправитель письма');
	
	if($result === true){
		echo "Success";
		header('location: about-project.php');
	}else{
		echo "Error: " . $result;
	}
	