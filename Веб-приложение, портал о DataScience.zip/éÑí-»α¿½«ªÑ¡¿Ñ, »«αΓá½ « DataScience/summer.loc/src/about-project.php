<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" href="img/icon/data.ico">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/slick.css">
  <link rel="stylesheet" href="css/slick-theme.css">
  <title>About project</title>
</head>
<body>

<?php include 'includes/header.php'; ?>

<section class="hero" id="hero">
        <div class="container">
          <div class="hero-block">
            <div class="hero-text">
              <h1 class="hero-text__title">
                 Цель проекта
              </h1>
              <span class="hero-text__subtitle">Сформировать информационное сообщество вокруг data science</span>
              <ul class="hero-list">
                <li class="hero-list__item">
                  <div class="hero-list__image">
                    <img src="img/hero/notebook.png" alt="5">
                  </div>
                  <span class="hero-list__text">Делимся своим опытом</span>
                </li>
                <li class="hero-list__item">
                  <div class="hero-list__image">
                    <img src="img/hero/pencil.png" alt="24">
                  </div>
                  <span class="hero-list__text">Помогаем создавать новые идеи</span>
                </li>
                <li class="hero-list__item">
                  <div class="hero-list__image">
                    <img src="img/hero/uni.png" alt="reload">
                  </div>
                  <span class="hero-list__text">Предоставляем качественный материал для обучения</span>
                </li>
                <li class="hero-list__item">
                    <div class="hero-list__image">
                      <img src="img/hero/photos.png" alt="map-location">
                    </div>
                    <span class="hero-list__text">Взращиваем число сторонников</span>
                </li>
                <li class="hero-list__item">
                    <div class="hero-list__image">
                      <img src="img/hero/news.png" alt="map-location">
                    </div>
                    <span class="hero-list__text">Публикуем качественные новости науки</span>
                </li>
              </ul>
            </div>
            <!-- /.hero-text -->
            <div class="hero-form" index="hero__form">
                <form action="mail.php" method="POST" class="form hero__form" id="hero__form">
                    <div class="hero__form-wrap">
                      <h3 class="hero__form-title">Задайте нам вопрос и мы <span class="hero__form-bold">обязательно вам ответим</span></h3>
                      <input type="text" name="username" class="input hero__input hero__input_1" placeholder="Ваше имя">
                      <input type="email" name="email" class="input hero__input hero__input_2" placeholder="Электронная почта">
                      <textarea type="text" name="text" class="input hero__input hero__input_3" placeholder="Ваше сообщение"></textarea>
                    </div>
                    <button class="button hero__button" id="button-thx">Задать вопрос</button>
                </form>
            </div>
            <!-- /.hero-image -->
          </div>
          <!-- /.hero-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.hero -->

      <section class="section customer" id="customer">
              <div class="container">
                <h2 class="customer__title">
                  Благодарим следующие веб-проекты за предоставленную информацию
                </h2>
                <div class="slider-block-cust">
                  <div class="arrows__left arrows__left-cust">
                    <img src="img/slider/left-arrow.svg" alt="left-arrow">
                  </div>
                  <div class="slider slider__customer" data-wow-delay="0.2s">
                    <div class="slider__item slider__item-cust">
                      <div class="slider__img-wrap-cust">
                        <a href="https://ru.wikipedia.org/" class="slider-link">
                          <img class="slider__img slider__img-cust" src="img/slider/wiki.png" alt="slider-1">
                        </a>
                      </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                      <div class="slider__img-wrap-cust">
                      <a href="https://habr.com/ru/" class="slider-link">
                          <img class="slider__img slider__img-cust" src="img/slider/habr.png" alt="slider-2">
                      </a>
                      </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                      <div class="slider__img-wrap-cust">
                      <a href="https://www.kaggle.com" class="slider-link">
                          <img class="slider__img slider__img-cust" src="img/slider/kaggle.jpg" alt="slider-3">
                      </a>
                      </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                        <div class="slider__img-wrap-cust">
                      <a href="https://www.coursera.org" class="slider-link">
                            <img class="slider__img slider__img-cust" src="img/slider/coursera.png" alt="slider-4">
                      </a>
                        </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                        <div class="slider__img-wrap-cust">
                      <a href="https://welcome.stepik.org/ru" class="slider-link">
                            <img class="slider__img slider__img-cust" src="img/slider/stepik.png" alt="slider-5">
                      </a>
                        </div>
                    </div>

                   <div class="slider__item slider__item-cust">
                      <div class="slider__img-wrap-cust">
                      <a href="https://ru.wikipedia.org/" class="slider-link">
                        <img class="slider__img slider__img-cust" src="img/slider/wiki.png" alt="slider-6">
                      </a>
                      </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                      <div class="slider__img-wrap-cust">
                      <a href="https://habr.com/ru/" class="slider-link">
                          <img class="slider__img slider__img-cust" src="img/slider/habr.png" alt="slider-7">
                      </a>
                      </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                      <div class="slider__img-wrap-cust">
                      <a href="https://www.kaggle.com" class="slider-link">
                          <img class="slider__img slider__img-cust" src="img/slider/kaggle.jpg" alt="slider-8">
                      </a>
                      </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                        <div class="slider__img-wrap-cust">
                        <a href="https://www.coursera.org" class="slider-link">
                            <img class="slider__img slider__img-cust" src="img/slider/coursera.png" alt="slider-9">
                        </a>
                        </div>
                    </div>
                    <div class="slider__item slider__item-cust">
                        <div class="slider__img-wrap-cust">
                        <a href="https://welcome.stepik.org/ru" class="slider-link">
                            <img class="slider__img slider__img-cust" src="img/slider/stepik.png" alt="slider-10">
                        </a>
                          </div>
                    </div>
                </div>
                  <div class="arrows__right arrows__right-cust">
                    <img src="img/slider/right-arrow.svg" alt="right-arrow">
                  </div>
                </div>
                </div>
              </div>
              <!-- /.container -->
            </section>
            <!-- /.section customer -->
            
      <section class="section map" id="map">
        <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A7b8a0fffbdb44826e5b707ee16bbda15f73e184f9b7fb03084d01aa6aacce742&amp;width=100%25&amp;height=500&amp;lang=ru_RU&amp;scroll=false">
        </script>
      </section>

      <?php include 'includes/footer.php'; ?>

</body>
</html>