<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
            "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/magnifier.css">
  <title>Карта наук</title>
</head>
<body>
<?php include 'includes/header.php'; ?>
<section class="main">
        <div class="container">
          <div class="main-block">
          <h1 class="hero-text__title science__title">
                 Карта наук Data Science
              </h1>
              <span class="hero-text__subtitle science__subtitle">В данном разделе вы можете посмотреть карту наук Data Science. Для этого <br>наведите курсором на интересующее вас место карты</span>
          <div>
    <div class="magnifier-thumb-wrapper" href="">
        <img id="thumb" src="img/science-map/science-map.svg"
        data-large-img-url="img/science-map/science-map.svg"
        data-large-img-wrapper="preview">
</div>
    <div class="magnifier-preview" id="preview"></div>
</div>

          </div>
          <!-- /.main-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.main -->

<?php include 'includes/footer.php'; ?>
<script type="text/javascript" src="js/Event.js"></script>
<script type="text/javascript" src="js/Magnifier.js"></script>
<script type="text/javascript">
    var evt = new Event();
        m = new Magnifier(evt);

        m.attach({
            thumb: '#thumb',
            large: 'img/science-map/science-map.svg',
            largeWrapper: 'preview',
            zoom: 10,
            zoomable: false
        });

</script>

</body>
</html>