<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" href="img/icon/data.ico">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">

  <title>Courses</title>
</head>
<body>

  <div class="nav-wrapper">
    <?php include 'includes/header.php'; ?>
  </div>


    
    <section class="courses">
        <div class="container">
          <div class="courses-block">
              <div class="info-title courses-title">
                <h2 class="info-title__title courses-title">Курсы и книги</h2>
              </div>
              <p class="info__text">Друзья, все мы знаем, что главное в Data Science – учёба. 
                А если быть точнее, то самообучение. В данном разделе спешим 
                порекомендовать вам некоторые книги, а также курсы, пройдя которые, вы значительно пополните 
                свой багаж знаний в областях обработки и анализа данных.</p>

          </div>
          <!-- /.courses-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.courses -->
      <section class="courses-cards">
        <div class="container">
            <h2 class="cards__title">Математика</h2>
            <span class="section-subtitle price__subtitle">Всеми любимая царица наук</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Необходимая литература для начала</h4>
                <div class="card__image"><img src="img/courses/books.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                  <span class="card__string">Кузнецова С.Н. Линейная алгебра <br>и аналитическая геометрия</span>
                  <span class="card__string">Гланц. Медико-биологическая статистика</span>
                  <span class="card__string">Савельев В. Статистика и котики</span>
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://www.litres.ru/'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Линейной алгебре</h4>
                <div class="card__image"><img src="img/courses/linear.png" alt="city"></div>
                <!-- /.card__image -->
                <div class="card__text">
                    <span class="card__string"><a href="https://www.coursera.org/learn/algebra-lineynaya" class="card__a">Курс на Coursera</a></span>
                    <span class="card__string"><a href="https://www.youtube.com/playlist?list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab" class="card__a">Классный Youtube-канал</a></span>
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price2" id="count__price2" onclick="location.href='https://www.coursera.org/learn/algebra-lineynaya'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                  <h4 class="card__title">Курс по теории вероятностей</h4>
                <div class="card__image"><img src="img/courses/possibility.png" alt="factory"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price3" id="count__price3" onclick="location.href='https://www.coursera.org/learn/probability-theory-basics'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Курсы по статистике</h4>
                <div class="card__image"><img src="img/courses/statistic.png" alt="interior"></div>
                <!-- /.card__image -->
                <div class="card__text">
                    <span class="card__string"><a href="https://stepik.org/course/Основы-статистики-76" class="card__a">Курс на Stepik</a></span>
                    <span class="card__string"><a href="https://www.class-central.com/course/edx-ut-7-01x-foundations-of-data-analysis-2244" class="card__a">Основательный курс часть I</a></span>
                    <span class="card__string"><a href="https://www.class-central.com/course/edx-foundations-of-data-analysis-part-2-inferential-statistics-4804" class="card__a">Основательный курс часть II</a></span>
                    <span class="card__string"><a href="https://www.class-central.com/course/edx-i-heart-stats-learning-to-love-statistics-3048" class="card__a">Поверхностный курс</a></span>
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price4" id="count__price4" onclick="location.href='https://stepik.org/course/Основы-статистики-76'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              
          </div>
        </div>
      </section>

      <section class="courses">
        <div class="container">
        <h2 class="cards__title">Python</h2>
        <span class="section-subtitle price__subtitle">Язык программирования есть язык программирования. Тут ничего не попишешь</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Необходимые для старта курсы</h4>
                <div class="card__image"><img src="img/courses/py.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                  <span class="card__string"><a href="https://stepik.org/course/Программирование-на-Python-67" class="card__a">Курс на Stepik</a></span>
                  <span class="card__string"><a href="https://habr.com/company/compscicenter/blog/280426/" class="card__a">Курс на Coursera</a></span>
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://stepik.org/course/Программирование-на-Python-67'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
          </div>
        </div>
        <!-- /.container -->
      </section>
      <!-- /.courses -->

      <section class="courses-cards">
        <div class="container">
            <h2 class="cards__title">Data Science</h2>
            <span class="section-subtitle price__subtitle">Наконец-то внедрение в заветную область</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Курс от MIPT/Yandex на Coursera</h4>
                <div class="card__image"><img src="img/courses/coursera.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://www.coursera.org/specializations/machine-learning-data-analysis'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Бесплатный курс от <br>Open Data Science</h4>
                <div class="card__image"><img src="img/courses/open-data.png" alt="city"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price2" id="count__price2" onclick="location.href='https://github.com/Yorko/mlcourse_open'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              
          </div>
        </div>
      </section>

      <section class="courses">
        <div class="container">
            <h2 class="cards__title">Deep Learning</h2>
            <span class="section-subtitle price__subtitle">Для продвинутых</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Введение в Deep Learning</h4>
                <div class="card__image"><img src="img/courses/neuroweb.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                  <span class="card__string"><a href="https://www.youtube.com/playlist?list=PLZHQObOWTQDNU6R1_67000Dx_ZCJB-3pi" class="card__a">Нейроные сети собственной персоной</a></span>
                  <span class="card__string"><a href="http://course.fast.ai" class="card__a">Вводный курс по Deep Learning</a></span>
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://www.youtube.com/playlist?list=PLZHQObOWTQDNU6R1_67000Dx_ZCJB-3pi'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Классика Deep Learning <br>(Курс от Adrew Ng)</h4>
                <div class="card__image"><img src="img/courses/deep.png" alt="city"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price2" id="count__price2" onclick="location.href='https://www.coursera.org/specializations/deep-learning'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Курс по Computer Vision</h4>
                <div class="card__image"><img src="img/courses/vision.png" alt="city"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price2" id="count__price2" onclick="location.href='http://cs231n.stanford.edu'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Курс по Байесовским методам <br>машинного обучения</h4>
                <div class="card__image"><img src="img/courses/bayes.png" alt="city"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price2" id="count__price2" onclick="location.href='https://www.coursera.org/learn/bayesian-methods-in-machine-learning'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.courses -->



      <section class="courses-cards">
        <div class="container">
            <h2 class="cards__title">Reinforcement Learning</h2>
            <span class="section-subtitle price__subtitle">Для одичалых</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Курс от OpenAI</h4>
                <div class="card__image"><img src="img/courses/openai.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://spinningup.openai.com/en/latest/'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              
          </div>
        </div>
      </section>

      <section class="courses">
        <div class="container">
            <h2 class="cards__title">Big Data</h2>
            <span class="section-subtitle price__subtitle">Больше - лучше</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Курс по работе <br>с большими данными</h4>
                <div class="card__image"><img src="img/courses/big-data.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://www.coursera.org/learn/big-data-essentials?specialization=big-data-engineering'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.courses -->


      <section class="courses-cards">
        <div class="container">
            <h2 class="cards__title">Machine Learning Соревнования</h2>
            <span class="section-subtitle price__subtitle">Участвуй, побеждай, повышай самооценку!</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Введение в соревнования <br>и первые начинания</h4>
                <div class="card__image"><img src="img/courses/kaggle.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                  <span class="card__string"><a href="https://www.kaggle.com/c/titanic" class="card__a">Титаник - классика Kaggle</a></span>
                  <span class="card__string"><a href="https://www.kaggle.com/c/telecom-clients-churn-prediction" class="card__a">Прогноизрование оттока пользователей</a></span>
                  <span class="card__string"><a href="https://www.kaggle.com/c/product-reviews-sentiment-analysis-light" class="card__a">Сентимент-анализ отзывов на товары</a></span>
                  <span class="card__string"><a href="https://www.youtube.com/watch?v=fXnzjJMbujc" class="card__a">Youtube-плейлист о cоревнованиях на Kaggle</a></span>
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://www.kaggle.com/c/titanic'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              
          </div>
        </div>
      </section>




      <section class="courses">
        <div class="container">
            <h2 class="cards__title">Алгоритмы</h2>
            <span class="section-subtitle price__subtitle">Пригодится на собеседовании</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Курс на Stepik</h4>
                <div class="card__image"><img src="img/courses/stepik.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://stepik.org/course/217'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Видеолекции курса<br> "Алгоритмы и структуры данных"<br> от ШАД</h4>
                <div class="card__image"><img src="img/courses/yandex.png" alt="city"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price2" id="count__price2" onclick="location.href='https://yandexdataschool.ru/edu-process/courses/algorithms'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              <div class="card price__card">
                <h4 class="card__title">Платформа LeetCode<br> с кучей алгоритмических задач</h4>
                <div class="card__image"><img src="img/courses/leetcode.png" alt="city"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price2" id="count__price2" onclick="location.href='https://leetcode.com/'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.courses -->








      <section class="courses-cards">
        <div class="container">
            <h2 class="cards__title">Английский язык</h2>
            <span class="section-subtitle price__subtitle">Прости, но ты живёшь в России</span>
          <div class="cards-block">
            <div class="card price__card">
                <h4 class="card__title">Занятия EnglishDom</h4>
                <div class="card__image"><img src="img/courses/englishdom.png" alt="architecture"></div>
                <!-- /.card__image -->
                <div class="card__text">
                </div>
                <!-- /.card__text -->
                <button class="button price__btn count__price" id="count__price" onclick="location.href='https://www.englishdom.com/'">Перейти на сайт</button>
              </div>
              <!-- /.card -->
              
          </div>
        </div>
      </section>






<!-- _________________________________________________________________ -->


<section class="courses">
        <div class="container">
          <div class="courses-block">
          <p class="info__text">Говорят, был один герой, который прошёл ВСЕ эти курсы. Но это всего лишь легенда...</p>
              <p class="info__text">Друзья, этот список регулярно обновляется. Вы можете помочь его завершению, нажав на кнопку <a class="footer__order" id="course-suggest">предложить новость</a></p>
          </div>
          <!-- /.courses-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.courses -->





  <?php include 'includes/footer.php'; ?>


</body>
</html>