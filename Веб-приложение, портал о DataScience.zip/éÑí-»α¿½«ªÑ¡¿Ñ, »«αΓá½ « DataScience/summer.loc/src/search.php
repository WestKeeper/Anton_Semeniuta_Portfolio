<!DOCTYPE html>
<html lang="ru">
<head>
<?php
    require_once "functions/functions.php";
  ?>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" href="img/icon/data.ico">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">

  <title>Результаты поиска</title>
</head>
<body>

  <?php include 'includes/header.php'; ?>

  <?php 
    function search($words){
      $words = htmlspecialchars($words);
      $words = trim($words);
      if ($words === "") return false;
      $query_search = "";

      $arraywords = explode (" ", $words);
      foreach ($arraywords as $key => $value){
        if (isset($arraywords[$key - 1]))
          $query_search .= ' OR ';
        $query_search .= 'title LIKE "%'.$value.'%" OR full_text LIKE "%'.$value.'%"';
      }
      $query = "SELECT * FROM news WHERE $query_search ORDER BY id DESC";
      $result_set = searchDB($query);

      $i = 0;
      while($row = $result_set->fetch_assoc()){
        $results[$i] = $row;
        $i++;
      }
      return $results;
    }

    if (isset($_GET['bsearch'])){
      $words = $_GET['words'];
      $results = search($words);
    }
    ?>
    
    <section class="main">
        <div class="container">
          <div class="main-block">

         
          <?php include 'includes/search-form.php'; ?>

            <?php
              if (isset($_GET['bsearch'])){
                echo "<h1 class=\"hero-text__title hero-text__title-search\">Результаты поиска</h1>";
                if (trim($words) === "") echo "<span class=\"hero-text\">Вы задали пустой запрос</span>";
                else
                if (count($results) === 0) echo "<span class=\"hero-text\">Ничего не найдено</span>";
                else
                  for ($i = 0; $i < count($results); $i++){
                    echo "<div class=\"article\">
                    <div class=\"article-top\">
                      <span class=\"article-top__text\">".$results[$i]["date"].", ".$results[$i]["kind"]."</span>
                    </div>
                    <div class=\"article-title\">
                      <h2 class=\"article-title__text\">".$results[$i]["title"]."</h2>
                    </div>
                    <div class=\"article-img\">
                      <img src=\"img/main/articles/article_".$results[$i]["id"].".jpg\" alt=\"article-img\">
                    </div>
                    <div class=\"article-intro\">
                      <span class=\"link-intro\">".$results[$i]["intro_text"]."</span>
                    <a href=\"article.php?id=".$results[$i]["id"]."\" class=\"link-intro link-intro__a\"> . . .</a>
                    </div>
                    <button class=\"article-btn button\" onclick=\"location.href='article.php?id=".$results[$i]["id"]."'\">Далее</button>
                  </div>";;
                  }
              }
            ?>

            <div class="suggest">
              <div class="suggest-text">
                <h2 class="suggest-text__title">Предложения</h2>
                <a href="#" class="suggest-text__order" id="suggest__order">Предложить идею</a>
              </div>
            </div>

          </div>
          <!-- /.hero-block -->
        </div>
        <!-- /.container -->
      </section>
      <!-- /.hero -->


  <?php include 'includes/footer.php'; ?>


</body>
</html>