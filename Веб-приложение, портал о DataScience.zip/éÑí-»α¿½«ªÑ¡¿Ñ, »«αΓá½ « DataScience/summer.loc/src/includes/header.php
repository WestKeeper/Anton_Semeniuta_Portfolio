<nav class="navbar">
    <div class="container">
      <div class="navbar-block">
        <div class="navbar__menu">
          <a href="#" class="navbar__menu-btn" id="menu-btn">
            <span class="navbar__menu-span"></span>
            <span class="navbar__menu-text">Меню</span>
          </a>
          <ul class="navbar__menu-points" id="navbar__menu-points">
              <li class="navbar__menu-point"><a href="index.php" class="navbar__a a_bord">Главная</a></li>
              <li class="navbar__menu-point submenu-link__1"><a href="math-statistics.php" class="navbar__a">Базовые знания</a>
                <ul class="submenu submenu__1">
                  <li class="navbar__menu-point"><a href="math-statistics.php">Мат. статистика</a></li>
                  <li class="navbar__menu-point"><a href="linear-algebra.php" class="navbar__menu-point-link2">Линейная алгебра</a></li>
                  <li class="navbar__menu-point"><a href="it.php">Информатика</a></li>
                </ul>
              </li>
              <li class="navbar__menu-point submenu-link__2"><a href="sas.php" class="navbar__a">Языки</a>                
                <ul class="submenu submenu__2">
                  <li class="navbar__menu-point"><a href="sas.php">SAS</a></li>
                  <li class="navbar__menu-point"><a href="python.php" class="navbar__menu-point-link2">Python</a></li>
                  <li class="navbar__menu-point"><a href="r.php">R</a></li>
              </ul></li>
              <li class="navbar__menu-point submenu-link__3"><a href="about-dc.php" class="navbar__a">Основы DC</a>
                <ul class="submenu submenu__3">
                  <li class="navbar__menu-point"><a href="about-dc.php">Коротко о DC</a></li>
                  <li class="navbar__menu-point"><a href="how-it-works.php" class="navbar__menu-point-link2">"Как это работает?"</a></li>
                  <li class="navbar__menu-point"><a href="supervised-learning.php">Обучение с учителем</a></li>
                  <li class="navbar__menu-point"><a href="unsupervised-learning.php" class="navbar__menu-point-link2">Обучение без учителя</a></li>
                  <li class="navbar__menu-point"><a href="science-map.php">Карта наук DC</a></li>
                </ul>
              </li>
              <li class="navbar__menu-point submenu-link__4"><a href="#" class="navbar__a">Обработка и анализ</a>
              <ul class="submenu submenu__4">
                <li class="navbar__menu-point"><a href="data-preprocessing.php">Пред. обработка</a></li>
                <li class="navbar__menu-point"><a href="data-analysis.php" class="navbar__menu-point-link2">Анализ данных</a></li>
              </ul></li>
              <li class="navbar__menu-point submenu-link__5"><a href="deep-learning.php" class="navbar__a">Продвинутый уровень</a>
              <ul class="submenu submenu__5">
                <li class="navbar__menu-point"><a href="deep-learning.php">Deep Learning</a></li>
                <li class="navbar__menu-point"><a href="reinforcement-learning.php" class="navbar__menu-point-link2">Reinforcement Learning</a></li>
              </ul></li>
              <li class="navbar__menu-point"><a href="courses.php" class="navbar__a">Курсы</a></li>
              <li class="navbar__menu-point"><a href="about-project.php" class="navbar__a">О проекте</a></li>
          </ul>
        </div>
        <!-- /.navbar__menu -->
        <div class="navbar__logo">
          <div class="navbar-logo__image">
            <a href="index.php" class="navbar-logo-img">
              <img src="img/nav/logo.png" alt="map-location">
            </a>
          </div>
        </div>
        <!-- /.navbar__logo -->
      </div>
      <!-- /.navbar-block -->
    </div>
    <!-- /.container -->
  </nav>



  <section class="modal-menu" id="modal-menu">
      <ul class="navbar__modal-menu-points" id="navbar__modal-menu-points">
          <li class="navbar__modal-menu-point"><a href="index.php" class="navbar__model-a">Главная</a></li>
          <li class="navbar__modal-menu-point"><a class="navbar__model-a" id="base-knowledge">Базовые знания</a></li>
          <div class="navbar__modal-sub" id="base-knowledge-sub">
            <li class="navbar__modal-li"><a href="#" class="navbar__modal-a-sub">Мат. статистика</a></li>
            <li class="navbar__modal-li"><a href="#" class="navbar__modal-a-sub">Линейная алгебра</a></li>
            <li class="navbar__modal-li"><a href="#" class="navbar__modal-a-sub">Мат. анализ</a></li>
          </div>
          <li class="navbar__modal-menu-point"><a class="navbar__model-a" id="lang">Языки</a></li>
          <div class="navbar__modal-sub" id="lang-sub">
            <li class="navbar__modal-li"><a href="sas.php" class="navbar__modal-a-sub">SAS</a></li>
            <li class="navbar__modal-li"><a href="python.php" class="navbar__modal-a-sub">Python</a></li>
            <li class="navbar__modal-li"><a href="r.php" class="navbar__modal-a-sub">R</a></li>
          </div>
          <li class="navbar__modal-menu-point"><a class="navbar__model-a" id="dc">Основы DC</a></li>
          <div class="navbar__modal-sub" id="dc-sub">
            <li class="navbar__modal-li"><a href="about-dc.php" class="navbar__modal-a-sub">Коротко о DC</a></li>
            <li class="navbar__modal-li"><a href="how-it-works.php" class="navbar__modal-a-sub">"Как это работает?"</a></li>
            <li class="navbar__modal-li"><a href="supervised-learning.php" class="navbar__modal-a-sub">Обучение с учителем</a></li>
            <li class="navbar__modal-li"><a href="unsupervised-learning.php" class="navbar__modal-a-sub">Обучение без учителя</a></li>
          </div>
          <li class="navbar__modal-menu-point"><a class="navbar__model-a" id="convertion">Обработка и анализ</a></li>
          <div class="navbar__modal-sub" id="convertion-sub">
            <li class="navbar__modal-li"><a href="#" class="navbar__modal-a-sub">Пред. обработка</a></li>
            <li class="navbar__modal-li"><a href="#" class="navbar__modal-a-sub">Методы анализа</a></li>
          </div>
          <li class="navbar__modal-menu-point"><a class="navbar__model-a" id="high-level">Продвинутый уровень</a></li>
          <div class="navbar__modal-sub" id="high-level-sub">
            <li class="navbar__modal-li"><a href="deep-learning.php" class="navbar__modal-a-sub">Deep Learning</a></li>
            <li class="navbar__modal-li"><a href="reinforcement-learning.php" class="navbar__modal-a-sub">Reinforcement Learning</a></li>
          </div>
          <li class="navbar__modal-menu-point"><a href="courses.php" class="navbar__model-a">Курсы</a></li>
          <li class="navbar__modal-menu-point"><a href="about-project.php" class="navbar__model-a">О проекте</a></li>
      </ul>
  </section>