<form name="search" action="search.php" method="get" class="search">
  <div class="search-input">
    <input type="text" name="words" class="input search-input__input" placeholder="Поиск...">
  </div>
  <div class="search-btn">
  <button type="submit" name="bsearch" class="search-btn__button button">
    <img src="img/main/magnifier-tool.svg" alt="search" class="img-svg">
  </button>
  </div>
</form>