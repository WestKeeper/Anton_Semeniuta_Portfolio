<script src="js/jquery-3.3.1.js"></script>
<script src="js/menu-btn.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/slider-port.js"></script>
<script src="js/slider.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.js"></script>
<script src="js/my-validate.js"></script>
<script src="js/modal-thx.js"></script>

<div class="modal-thx" id="modal-thx">
      <div class="modal-dialog">
        <button class="button modal-dialog__close" id="close-thx">x</button> 
        <h4 class="modal-dialog__title">Дорогой друг, <br><br>Ваше сообщение отправлено. <br><br>Ждите нашего ответа в ближайшее время</h4>
      </div>
      <!-- /.modal-dialog -->
  </div>
  <!-- /.modal-thx -->

  <div class="modal-new" id="modal-new">
      <div class="hero-form hero-form-new">
          <form action="mail.php" method="POST" class="form hero__form hero__form-new" id="hero__form-new">
              <div class="button modal-dialog__close-new" id="close-thx-new">x</div>
              <div class="hero__form-wrap hero__form-wrap-new">
                <h3 class="hero__form-title hero__form-title-new">Напишите нам и мы <span class="hero__form-bold">обязательно ответим</span></h3>
                <input type="text" name="username" class="input hero__input hero__input-new hero__input_1" placeholder="Ваше имя">
                <input type="email" name="email" class="input hero__input hero__input-new hero__input_2" placeholder="Электронная почта">
                <textarea type="text" name="text" class="input hero__input hero__input-new hero__input_3" placeholder="Ваше сообщение"></textarea>
              </div>
                <button class="button hero__button hero__button-new" id="button-thx-new" type="submit">Задать вопрос</button>
          </form>
      </div>
  </div>

<footer class="footer" id="footer">
    <div class="container">
      <div class="footer-block">
          <div class="address-block">
              <div class="address__img">
                <img src="img/footer/label.png" alt="label">
              </div>
              <div class="address__text">
                <span class="address__city">г. Томск,</span>
                <span class="address__street">Пирогова 18-А, 208 и 214</span>
              </div>
            </div>
            <div class="footer__contacts">
              <span class="footer__authors footer__authors_1">Антон Семенюта</span>
              <span class="footer__authors footer__authors_2">Владислав Галлингер</span>
              <a class="footer__order" id="footer__order">Написать нам сообщение</a>
            </div>
      </div>
    </div>
  </footer>