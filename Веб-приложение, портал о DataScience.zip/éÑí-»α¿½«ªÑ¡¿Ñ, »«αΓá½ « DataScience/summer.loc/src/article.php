<?php
    require_once "functions/functions.php";
    $news = getNews(1, $_GET["id"]);
    $title = $news["title"];
    if ($_POST["check"]){
      $author = $_POST["author"];
      $message = $_POST["message"];
      comments($title, $author, $message);
      header("Location: ".$_SERVER["REQUEST_URI"]);
      exit;
    } 

?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" href="img/icon/data.ico">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/style.css">


  <title><?=$title?></title>
</head>
<body>

  <?php include 'includes/header.php'; ?>


    
    <section class="main">
        <div class="container">
          <div class="main-block">

          <?php 
          
            $show_img = base64_encode($news["img"]);
            echo  "<div class=\"article\">
            <div class=\"article-top\">
              <span class=\"article-top__text\">".$news["date"].", ".$news["kind"]."</span>
            </div>
            <div class=\"article-title\">
              <h2 class=\"article-title__text\">".$title."</h2>
            </div>
            <div class=\"article-img\">
              <img src=\"data:image/jpeg;base64, ".$show_img."\" alt=\"article-img\">
            </div>
            <div class=\"article-intro\">
              <span class=\"link-intro\"><p class='info__text'>";echo nl2br($news["full_text"]); echo"</p></span>
            </div>
          </div>";
  ?>
            <?php include 'includes/search-form.php'; ?>

            <div class="suggest">
              <div class="suggest-text">
                <h2 class="suggest-text__title">Предложения</h2>
                <a href="#" class="suggest-text__order" id="suggest__order">Предложить идею</a>
              </div>
            </div>

          </div>
          <!-- /.hero-block -->

          

        </div>
        <!-- /.container -->
      </section>
      <!-- /.hero -->

  



<style>
  .article-comments__form-input_hidden{
    display: none;
  }
</style>

      


  <section class="article-comments">
        <div class="container">
          <div class="article-comments">

          
      <div class="article-comments__form-wrap">
          <form method="POST" class="form article-comments__form" id="form__comments">
              <div class="article-comments__form-wrap-inside">
                <h3 class="article-comments__form-title">Оставьте ваш комментарий</span></h3>
                <textarea type="text" name="message" class="input article-comments__form-input input article-comments__form-input-message" placeholder="Ваше сообщение"></textarea>
                <input type="text" name="author" class="input article-comments__form-input" placeholder="Ваше имя">
                <input type="hidden" name="title" class="input article-comments__form-input article-comments__form-input_hidden" value="<?=$title?>">
                <input type="hidden" name="check" class="input article-comments__form-input article-comments__form-input_hidden" value="true">
              </div>
              <div class="article-comments__form-button-wrap">
                <button class="button article-comments__form-button" id="button__comment" type="submit">Отправить</button>
              </div>
          </form>
      </div>
  

  <?php
    
    $comments = checkComments($title);

    for ($i = 0; $i < count($comments); $i++){
      echo  "
      <div class=\"article-comments__buble\">
      <div class=\"article-comments__top\">
        <h3 class=\"article-comments__title\">".$comments[$i]["author"]."</h3>
        <span class=\"article-comments__date\">".$comments[$i]["comment_date"]."</span>
      </div>
      <p class=\"article-comments__text\">".$comments[$i]["comment_message"]."</p>
    </div>";
    }
  ?>
          </div>
        </div>
      </section>


  <?php include 'includes/footer.php'; ?>


</body>
</html>